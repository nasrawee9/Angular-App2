import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputDataValidator } from '../input-data.validator';

@Component({
  selector: 'app-caculator',
  templateUrl: './caculator.component.html',
  styleUrls: ['./caculator.component.css']
})
export class CaculatorComponent implements OnInit {
  dataForm!: FormGroup;
  resultArray: number[][] = [];
  timeExecutions: number[] = [];
  showResult = false;

  constructor() { }

  ngOnInit(): void {
    // init form
    this.dataForm = this.initForm();
  }

  initForm(): FormGroup {
    // return empty
    return new FormGroup({
      // init form control, required at least first line and match the pattern, also not exceed 10 items per line by custom validator
      line1: new FormControl('', [Validators.required, InputDataValidator]),
    })
  }

  // check form invalid
  isControlInvalid(formGroup: FormGroup, controlName: string): boolean {
    // get control from form group
    const control = formGroup.controls[controlName];
    // check if invalid and touched then return status
    return control.invalid && (control.dirty || control.touched);
  }

  // on submit
  onSubmit() {
    this.showResult = true;
    this.processData();
  }

  // clear result
  clearResult() {
    this.resultArray = [];
    this.timeExecutions = [];
    this.showResult = false;
    this.dataForm.controls['line1'].setValue('');
  }

  // get form value
  formValue(): number[][] {
    // get form value from control and parse to array of number
    // first get form control data, then use split by line, then split by comma, but it still has space, so use trim to remove space, then parse to number
    let line1: number[][] = this.dataForm.controls['line1'].value.split('\n').map((item: string) => item.trim().split(',').map(item => parseFloat(item)));
    // return array of number, not equal to NaN
    return line1;
  }

  processData() {
    
    // set result array to form value
    let line = this.formValue();
    // sort and filter array
   
    this.timeExecutions = [];
    
    // add result to result array
    this.resultArray = line.map((item: number[]) => {
      // sort and filter array
      item = this.sortAndFilterDuplicate(item);
      // add result to executions array
      // return result
      return item;
    })
    console.log(this.resultArray);
  }

  // sort and filter duplicate
  sortAndFilterDuplicate(arrays: number[]) {
    let timer = 0;
    // start timer
    let startTime = performance.now();
    console.log(startTime);
    // sort array
    arrays.sort((a: number, b: number) => a - b);
    // filter duplicate
    let result = [...new Set(arrays)];
    let endTime = performance.now();
    // get execution time
    timer = endTime - startTime;
    console.log(endTime);
    this.timeExecutions.push(timer);
    return result;
  }

  pushResult(result: number[]) {
    // add value line to result array
    this.resultArray.push(result);
  }

  // get error of form control
  controlHasError(formGroup: FormGroup, validation: string, controlName: string): boolean {
    const control = formGroup.controls[controlName];
    return control.hasError(validation) && (control.dirty || control.touched);
  }
}

