import { CaculatorComponent } from "./caculator.component";

describe('CalculatorComponent', () => {
  let component: CaculatorComponent;

  beforeEach(() => {
    component = new CaculatorComponent();
  })

  it('Test case 1', () => {
    let arrays = [4,2.2,3,5,10,5,3,2];
    expect(component.sortAndFilterDuplicate(arrays)).toEqual([2, 2.2, 3, 4, 5, 10]);
  });

  it('Test case 2', () => {
    let arrays = [3.1, 32, 54.4, 3.1, 23, 5, 1, 3];
    expect(component.sortAndFilterDuplicate(arrays)).toEqual([1, 3, 3.1, 5, 23, 32, 54.4]);
  });

  it('Test case 3', () => {
    let arrays = [4, 2.2, 3, 5, 10, 5, 3, 2, 12, 321];
    expect(component.sortAndFilterDuplicate(arrays)).toEqual([2, 2.2, 3, 4, 5, 10, 12, 321]);
  });

  it('Test case 4', () => {
    let arrays = [2, 1, 3, 5.1, 35, 6];
    expect(component.sortAndFilterDuplicate(arrays)).toEqual([1, 2, 3, 5.1, 6, 35]);
  });

  it('Test case 5', () => {
    let arrays = [312, 466, 5223, 123, 35, 3, 2, 1, 5];
    expect(component.sortAndFilterDuplicate(arrays)).toEqual([1, 2, 3, 5, 35, 123, 312, 466, 5223]);
  });

  it('Test case 6', () => {
    let arrays = [567.567, 756, 345, 765, 5436, 342, 1];
    expect(component.sortAndFilterDuplicate(arrays)).toEqual([1, 342, 345, 567.567, 756, 765, 5436]);
  });
})