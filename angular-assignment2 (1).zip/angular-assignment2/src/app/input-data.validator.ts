import { AbstractControl, ValidationErrors } from '@angular/forms'

export function InputDataValidator(control: AbstractControl): ValidationErrors | null {
  // get value from control
  const v = control.value;
  // get value by using split to turn it to array, then filter space items.
  const array = v.split(',').filter((x: any) => x != ' ' || x != '');

  // if array length exceed 10, return error
  if (array.length > 10) {
    return { 'inputData': true }
  }
  // if array length less than 10, return good
  else {
    return null;
  }

}