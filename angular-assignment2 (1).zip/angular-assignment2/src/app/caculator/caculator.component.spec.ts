import { CaculatorComponent } from "./caculator.component";

describe('CalculatorComponent', () => {
  let component: CaculatorComponent;

  beforeEach(() => {
    component = new CaculatorComponent();
  })

  it('Test case 1', () => {
    component.resultArray = [];
    component.generateTotalArray([[9, 5, 9],[2, 5, 7, 6, 9],[1]])
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1, 2, 5, 6, 7, 9]);
  });

  it('Test case 2', () => {
    component.resultArray = [];
    component.generateTotalArray([[3, 3, 3], [2,2,2,2], [1]])
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1,2,3]);
  })

  it('Test case 3', () => {
    component.resultArray = [];
    component.generateTotalArray([[1,3,4.1], [3.4]])
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1, 3, 3.4, 4.1]);
  })

  it('Test case 5', () => {
    component.resultArray = [];
    component.generateTotalArray([[123, 345, 131, 112, 345], [12, 34, 55, 1, 23, 4]]);
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1, 4, 12, 23, 34, 55, 112, 123, 131, 345]);
  })

  it('Test case 6', () => {
    component.resultArray = [];
    component.generateTotalArray([[123, 345, 131, 112, 345], [12, 34, 55, 1, 23, 4], [111, 23, 4, 511, 2, 3, 1212, 3], [2, 3, 1.5, 1.23]])
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1, 1.23, 1.5, 2, 3, 4, 12, 23, 34, 55, 111, 112, 123, 131, 345, 511, 1212]);
  })

  it('Test case 7', () => {
    component.resultArray = [];
    component.generateTotalArray([[9, 9], [2, 5, 7, 6], [1]])
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1, 2, 5, 6, 7, 9]);
  })

  it('Test case 8', () => {
    component.resultArray = [];
    component.generateTotalArray([[9, 5, 5, 2, 9], [2, 5, 7, 6, 9], [1, 1231321321,332,3455,1123]])
    component.sortAndFilterDuplicate();
    expect(component.resultArray).toEqual([1, 2, 5, 6, 7, 9, 332, 1123, 3455, 1231321321]);
  })
})