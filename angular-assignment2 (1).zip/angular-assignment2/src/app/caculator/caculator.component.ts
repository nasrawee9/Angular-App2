import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { InputDataValidator } from '../input-data.validator';

@Component({
  selector: 'app-caculator',
  templateUrl: './caculator.component.html',
  styleUrls: ['./caculator.component.css']
})
export class CaculatorComponent implements OnInit {
  dataForm!: FormGroup;
  resultArray: number[] = [];
  timer = 0;

  constructor() { }

  ngOnInit(): void {
    // init form
    this.dataForm = this.initForm();
  }

  initForm(): FormGroup {
    // return empty
    return new FormGroup({
      // init form control, required at least first line and match the pattern, also not exceed 10 items per line by custom validator
      line1: new FormControl('', [Validators.required, Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line2: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line3: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line4: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line5: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line6: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line7: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line8: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line9: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
      line10: new FormControl('', [Validators.pattern('^([0-9]+(\.[0-9]+)?,{1} ?)*[0-9]+(\.[0-9]+)?$'), InputDataValidator]),
    })
  }

  // check form invalid
  isControlInvalid(formGroup: FormGroup, controlName: string): boolean {
    // get control from form group
    const control = formGroup.controls[controlName];
    // check if invalid and touched then return status
    return control.invalid && (control.dirty || control.touched);
  }

  // on submit
  onSubmit() {
    this.processData();
  }

  // get form value
  formValue(): number[][] {
    // get form value from control and parse to array of number
    // first get form control data, then use split to create array, but it still has space, so use trim to remove space, then parse to number
    let line1: number[] = this.dataForm.controls['line1'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line2: number[] = this.dataForm.controls['line2'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line3: number[] = this.dataForm.controls['line3'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line4: number[] = this.dataForm.controls['line4'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line5: number[] = this.dataForm.controls['line5'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line6: number[] = this.dataForm.controls['line6'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line7: number[] = this.dataForm.controls['line7'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line8: number[] = this.dataForm.controls['line8'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line9: number[] = this.dataForm.controls['line9'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));
    let line10: number[] = this.dataForm.controls['line10'].value.split(',').filter((x: string) => x != ' ').map((x: string) => parseFloat(x));

    // return array of number, not equal to NaN
    return [line1, line2, line3, line4, line5, line6, line7, line8, line9, line10].filter((x: number[]) => !isNaN(x[0]));
  }

  // generateTotalArray. parameter is form lines
  generateTotalArray(formArrays: number[][]): void {
    formArrays.forEach((nums: number[]) => {
      this.concatArray(nums);
    })
  }

  //  concat array after process 
  concatArray(numbers: number[]):void {
    // using spread operator to push numbers to result array
    this.resultArray = [...this.resultArray, ...numbers];
  }


  processData() {
    // start timer
    let startTime = performance.now();
    // set empty array when submit
    this.resultArray = [];
    // concat all 10 lines
    this.generateTotalArray(this.formValue());
    // sort and filter array
    this.sortAndFilterDuplicate();
    console.log(this.resultArray); 
    let endTime = performance.now();
    this.timer = endTime - startTime;
  }

  // sort and filter duplicate
  sortAndFilterDuplicate() {
    // sort array
    this.resultArray.sort((a: number, b: number) => a - b);
    // filter duplicate
    this.resultArray = this.resultArray.filter((value: number, index: number, self: number[]) => self.indexOf(value) === index);
  }

  // get error of form control
  controlHasError(formGroup: FormGroup, validation: string, controlName: string): boolean {
    const control = formGroup.controls[controlName];
    return control.hasError(validation) && (control.dirty || control.touched);
  }
}

